# BicPop - Relational Database Model

## Overview
Este documento describe el modelo de base de datos relacional para la plataforma de alquiler de bicicletas BicPop en Popayán, Colombia.

## Entity Relationship Diagram (ERD)

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│     USERS       │    │      BIKES      │    │    BOOKINGS     │
├─────────────────┤    ├─────────────────┤    ├─────────────────┤
│ user_id (PK)    │    │ bike_id (PK)    │    │ booking_id (PK) │
│ first_name      │    │ name            │    │ user_id (FK)    │
│ last_name       │    │ type            │    │ bike_id (FK)    │
│ email           │    │ price_per_hour  │    │ start_time      │
│ password_hash   │    │ image_url       │    │ end_time        │
│ account_balance │    │ battery_level   │    │ duration_hours  │
│ kyc_status      │    │ location        │    │ total_cost      │
│ kyc_document    │    │ is_available    │    │ payment_method  │
│ created_at      │    │ created_at      │    │ booking_status  │
│ updated_at      │    │ updated_at      │    │ created_at      │
└─────────────────┘    └─────────────────┘    │ updated_at      │
         │                       │            └─────────────────┘
         │                       │                     │
         └───────────────────────┼─────────────────────┘
                                 │
┌─────────────────┐             │            ┌─────────────────┐
│    PAYMENTS     │             │            │   BIKE_TYPES    │
├─────────────────┤             │            ├─────────────────┤
│ payment_id (PK) │             │            │ type_id (PK)    │
│ booking_id (FK) │             │            │ type_name       │
│ user_id (FK)    │             │            │ description     │
│ amount          │             │            │ base_price      │
│ payment_method  │             │            │ features        │
│ payment_status  │             │            └─────────────────┘
│ transaction_id  │             │                     │
│ created_at      │             │                     │
└─────────────────┘             └─────────────────────┘
         │
         │
┌─────────────────┐
│ ACCOUNT_TOPUPS  │
├─────────────────┤
│ topup_id (PK)   │
│ user_id (FK)    │
│ amount          │
│ payment_method  │
│ card_last_four  │
│ transaction_id  │
│ status          │
│ created_at      │
└─────────────────┘
```

## Table Definitions

### 1. USERS
Almacena información de la cuenta del usuario y el estado de verificación KYC.

```sql
CREATE TABLE users (
    user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    account_balance DECIMAL(10,2) DEFAULT 0.00,
    kyc_status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
    kyc_document_url VARCHAR(500),
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### 2. TIPOS DE BICICLETAS
Define diferentes tipos de bicicletas disponibles (mecánicas, eléctricas).

```sql
CREATE TABLE bike_types (
    type_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type_name VARCHAR(50) NOT NULL, -- 'mechanical', 'electric'
    description TEXT,
    base_price_per_hour DECIMAL(8,2) NOT NULL,
    features JSON, -- Store features as JSON array
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 3. BICICLETAS
Inventario de bicicletas individuales con estado y ubicación actuales.

```sql
CREATE TABLE bikes (
    bike_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type_id UUID REFERENCES bike_types(type_id),
    name VARCHAR(100) NOT NULL,
    model VARCHAR(100),
    price_per_hour DECIMAL(8,2) NOT NULL,
    image_url VARCHAR(500),
    battery_level INTEGER CHECK (battery_level >= 0 AND battery_level <= 100),
    location_lat DECIMAL(10, 8),
    location_lng DECIMAL(11, 8),
    location_name VARCHAR(255),
    is_available BOOLEAN DEFAULT true,
    maintenance_status ENUM('active', 'maintenance', 'retired') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### 4. RESERVAS
Registros de alquileres de bicicletas y su estado.

```sql
CREATE TABLE bookings (
    booking_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(user_id) NOT NULL,
    bike_id UUID REFERENCES bikes(bike_id) NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    duration_hours INTEGER NOT NULL,
    total_cost DECIMAL(10,2) NOT NULL,
    payment_method ENUM('account_balance', 'credit_card') NOT NULL,
    booking_status ENUM('active', 'completed', 'cancelled') DEFAULT 'active',
    pickup_location VARCHAR(255),
    return_location VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### 5. PAGOS
Registros de transacciones para todos los pagos en el sistema.

```sql
CREATE TABLE payments (
    payment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID REFERENCES bookings(booking_id),
    user_id UUID REFERENCES users(user_id) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('account_balance', 'credit_card') NOT NULL,
    payment_type ENUM('booking', 'topup') NOT NULL,
    payment_status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    transaction_id VARCHAR(255),
    card_last_four VARCHAR(4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 6. CUENTA_TOPUPS
Registros de recargas de saldo de cuenta.

```sql
CREATE TABLE account_topups (
    topup_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(user_id) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('credit_card', 'bank_transfer') NOT NULL,
    card_last_four VARCHAR(4),
    transaction_id VARCHAR(255),
    status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Indexes for Performance

```sql
-- User lookups
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_kyc_status ON users(kyc_status);

-- Bike availability and location
CREATE INDEX idx_bikes_available ON bikes(is_available);
CREATE INDEX idx_bikes_type ON bikes(type_id);
CREATE INDEX idx_bikes_location ON bikes(location_lat, location_lng);

-- Booking queries
CREATE INDEX idx_bookings_user ON bookings(user_id);
CREATE INDEX idx_bookings_bike ON bookings(bike_id);
CREATE INDEX idx_bookings_status ON bookings(booking_status);
CREATE INDEX idx_bookings_dates ON bookings(start_time, end_time);

-- Payment tracking
CREATE INDEX idx_payments_user ON payments(user_id);
CREATE INDEX idx_payments_booking ON payments(booking_id);
CREATE INDEX idx_payments_status ON payments(payment_status);
```

## Relaciones

1. **Usuarios ↔ Reservas**: Uno a muchos (un usuario puede tener varias reservas)
2. **Bicicletas ↔ Reservas**: Una a varias (una bicicleta puede tener varias reservas a lo largo del tiempo)
3. **Reservas ↔ Pagos**: Uno a Uno (Cada reserva tiene un registro de pago)
4. **Usuarios ↔ Pagos**: Uno a muchos (un usuario puede tener múltiples pagos)
5. **Usuarios ↔ Recargas de cuenta**: Uno a muchos (un usuario puede tener múltiples recargas)
6. **Bike_Types ↔ Bikes**: Uno a muchos (un tipo puede tener varias bicicletas)

## Sample Data

### Bike Types
```sql
INSERT INTO bike_types (type_name, description, base_price_per_hour, features) VALUES
('mechanical', 'Traditional pedal bikes for city commuting', 3000.00, '["21-speed gears", "LED lights", "Basket", "Lock included"]'),
('electric', 'Electric-assisted bikes for effortless rides', 5000.00, '["Electric motor", "50km range", "USB charging", "GPS tracking", "Anti-theft alarm"]');
```

### Sample Bikes
```sql
INSERT INTO bikes (type_id, name, model, price_per_hour, image_url, battery_level, location_name, is_available) VALUES
((SELECT type_id FROM bike_types WHERE type_name = 'mechanical'), 'City Cruiser Pro', 'CC-2024', 3000.00, '/images/city-cruiser.jpg', NULL, 'Parque Caldas', true),
((SELECT type_id FROM bike_types WHERE type_name = 'electric'), 'EcoBike Elite', 'EB-2024', 5000.00, '/images/ecobike-elite.jpg', 85, 'Universidad del Cauca', true);
```

## Reglas comerciales

1. **Registro de usuario**: los usuarios deben completar la verificación KYC antes de realizar reservas
2. **Saldo de cuenta**: Los usuarios deben tener saldo suficiente o un método de pago válido.
3. **Disponibilidad de bicicletas**: solo se pueden reservar bicicletas disponibles
4. **Duración de la reserva**: Mínimo 1 hora, máximo 24 horas por reserva
5. **Procesamiento de pagos**: los pagos se procesan inmediatamente después de la confirmación de la reserva.
6. **Devolución de bicicletas**: las bicicletas deben devolverse en los lugares designados.

## Consideraciones de seguridad

1. **Almacenamiento de contraseñas**: las contraseñas se codifican mediante bcrypt
2. **Documentos KYC**: almacenados de forma segura con cifrado
3. **Datos de pago**: la información de la tarjeta de crédito está tokenizada, solo se almacenan los últimos 4 dígitos
4. **Datos de usuario**: información personal cifrada en reposo
5. **Acceso API**: tokens JWT para autenticación
6. **Pista de auditoría**: todas las transacciones registradas con marcas de tiempo

## Funciones de escalabilidad

1. **Claves primarias UUID**: compatible con sistemas distribuidos
2. **Particionado**: las tablas se pueden dividir por fecha para conjuntos de datos grandes
3. **Almacenamiento en caché**: Disponibilidad de bicicletas almacenada en caché para búsquedas rápidas
4. **Réplicas de lectura**: instancias de bases de datos de lectura/escritura separadas
5. **Índices**: optimizados para patrones de consulta comunes