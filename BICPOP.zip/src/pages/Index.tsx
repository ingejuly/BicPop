import { useState, useEffect } from 'react';
import LoginForm from '@/components/LoginForm';
import RegistrationForm from '@/components/RegistrationForm';
import BikeCatalog from '@/components/BikeCatalog';
import Header from '@/components/Header';
import AccountBalance from '@/components/AccountBalance';
import { mockBikes as bikes } from '@/lib/bikes';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Bike, Zap, CreditCard, Shield, Clock, MapPin, Star, Users } from 'lucide-react';

interface User {
  email: string;
  firstName: string;
  lastName: string;
  balance: number;
  kycVerified: boolean;
}

interface Booking {
  id: string;
  bike: string;
  duration: number;
  amount?: number;
  transaction_amount?: number;
  method: string;
  timestamp?: string;
  date_created?: string;
  status: string;
}

interface PaymentData {
  id: string;
  method: string;
  amount?: number;
  transaction_amount?: number;
  bike: string;
  duration: number;
  timestamp?: string;
  date_created?: string;
}

export default function Index() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showRegistration, setShowRegistration] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);

  // Check for existing session on component mount
  useEffect(() => {
    const savedUser = localStorage.getItem('bicpop_user');
    const savedBookings = localStorage.getItem('bicpop_bookings');
    
    if (savedUser) {
      const userData = JSON.parse(savedUser);
      setUser(userData);
      setIsLoggedIn(true);
    }
    
    if (savedBookings) {
      setBookings(JSON.parse(savedBookings));
    }
  }, []);

  const handleLogin = (email: string, password: string) => {
    // Mock login - in production, this would validate against a backend
    const userData: User = {
      email,
      firstName: 'Usuario',
      lastName: 'BicPop',
      balance: 75000, // Starting balance in COP
      kycVerified: true,
    };
    
    setUser(userData);
    setIsLoggedIn(true);
    setShowLogin(false);
    localStorage.setItem('bicpop_user', JSON.stringify(userData));
  };

  const handleRegistration = (userData: { email: string; firstName: string; lastName: string; password: string }) => {
    const newUser: User = {
      email: userData.email,
      firstName: userData.firstName,
      lastName: userData.lastName,
      balance: 75000, // Starting balance
      kycVerified: true, // Assume KYC is verified after registration
    };
    
    setUser(newUser);
    setIsLoggedIn(true);
    setShowRegistration(false);
    localStorage.setItem('bicpop_user', JSON.stringify(newUser));
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUser(null);
    setShowRegistration(false);
    setShowLogin(false);
    localStorage.removeItem('bicpop_user');
  };

  const handlePaymentSuccess = (paymentData: PaymentData) => {
    const newBooking: Booking = {
      id: `BOOK_${Date.now()}`,
      ...paymentData,
      timestamp: new Date().toISOString(),
      status: 'confirmed',
    };
    
    const updatedBookings = [...bookings, newBooking];
    setBookings(updatedBookings);
    localStorage.setItem('bicpop_bookings', JSON.stringify(updatedBookings));
    
    alert(`¡Reserva confirmada! 🚴‍♀️\n\nBicicleta: ${paymentData.bike}\nDuración: ${paymentData.duration} hora(s)\nMétodo de pago: ${paymentData.method === 'account_balance' ? 'Saldo de cuenta' : 'Mercado Pago'}\n\n¡Disfruta tu viaje!`);
  };

  const handleBalancePayment = (amount: number) => {
    if (user) {
      const updatedUser = { ...user, balance: user.balance - amount };
      setUser(updatedUser);
      localStorage.setItem('bicpop_user', JSON.stringify(updatedUser));
    }
  };

  const handleAddFunds = (amount: number) => {
    if (user) {
      const updatedUser = { ...user, balance: user.balance + amount };
      setUser(updatedUser);
      localStorage.setItem('bicpop_user', JSON.stringify(updatedUser));
    }
  };

  // Show registration form
  if (showRegistration) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-blue-50 to-green-50">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-emerald-600 mb-2">🚴‍♀️ BicPop</h1>
            <p className="text-gray-600">Registro de usuario</p>
          </div>
          <RegistrationForm
            onRegistrationSuccess={handleRegistration}
            onBackToLogin={() => setShowRegistration(false)}
          />
        </div>
      </div>
    );
  }

  // Show login form
  if (showLogin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-blue-50 to-green-50">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-emerald-600 mb-2">🚴‍♀️ BicPop</h1>
            <p className="text-gray-600">Iniciar sesión</p>
          </div>
          <div className="max-w-md mx-auto">
            <div className="bg-white rounded-2xl shadow-xl p-8 border border-emerald-100">
              <h2 className="text-2xl font-semibold text-center text-gray-800 mb-6">
                Iniciar Sesión
              </h2>
              <LoginForm
                onLogin={handleLogin}
                onShowRegistration={() => {
                  setShowLogin(false);
                  setShowRegistration(true);
                }}
              />
              <Button
                variant="ghost"
                onClick={() => setShowLogin(false)}
                className="w-full mt-4"
              >
                Volver al inicio
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Show main application if logged in
  if (isLoggedIn) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header
          user={user}
          onLogout={handleLogout}
        />
        
        <main className="container mx-auto px-4 py-6">
          <div className="mb-6">
            <div className="bg-gradient-to-r from-emerald-500 to-blue-500 rounded-2xl p-6 text-white mb-6">
              <h1 className="text-2xl font-bold mb-2">
                ¡Bienvenido, {user?.firstName}! 🚴‍♀️
              </h1>
              <p className="text-emerald-100">
                Encuentra tu bicicleta perfecta en Popayán
              </p>
            </div>
            
            <AccountBalance
              balance={user?.balance || 0}
              onAddFunds={handleAddFunds}
            />
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-800">
                Catálogo de Bicicletas
              </h2>
              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <span className="flex items-center space-x-1">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
                  <span>{bikes.filter(b => b.type === 'mechanical').length} Mecánicas</span>
                </span>
                <span className="flex items-center space-x-1">
                  <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                  <span>{bikes.filter(b => b.type === 'electric').length} Eléctricas</span>
                </span>
              </div>
            </div>
            
            <BikeCatalog
              userEmail={user?.email || ''}
              userBalance={user?.balance || 0}
              onPaymentSuccess={handlePaymentSuccess}
              onBalancePayment={handleBalancePayment}
            />
          </div>

          {bookings.length > 0 && (
            <div className="mt-6 bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">
                Historial de Reservas ({bookings.length})
              </h3>
              <div className="space-y-3">
                {bookings.slice(-3).reverse().map((booking) => {
                  const monto = booking.amount ?? booking.transaction_amount;
                  const fecha = booking.timestamp || booking.date_created;

                  return (
                    <div
                      key={booking.id}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                    >
                      <div>
                        <p className="font-medium text-gray-800">{booking.bike}</p>
                        <p className="text-sm text-gray-600">
                          {booking.duration} hora(s) •{' '}
                          {booking.method === 'account_balance' ? 'Saldo' : 'Mercado Pago'}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-emerald-600">
                          {typeof monto === 'number'
                            ? `$${monto.toLocaleString('es-CO')} COP`
                            : '---'}
                        </p>
                        <p className="text-xs text-gray-500">
                          {fecha
                            ? new Date(fecha).toLocaleDateString('es-CO')
                            : 'Fecha desconocida'}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </main>
      </div>
    );
  }

  // Landing page with prominent features
  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-blue-50 to-green-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-emerald-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <h1 className="text-2xl font-bold text-emerald-600">🚴‍♀️ BicPop</h1>
              <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                Mercado Pago ✓
              </Badge>
            </div>
            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowLogin(true)}
                className="border-emerald-200 text-emerald-700 hover:bg-emerald-50"
              >
                Iniciar Sesión
              </Button>
              <Button
                onClick={() => setShowRegistration(true)}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                Registrarse
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Alquiler de Bicicletas en
            <span className="text-emerald-600"> Popayán</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Explora la ciudad blanca con nuestras bicicletas mecánicas y eléctricas. 
            Pago seguro con Mercado Pago y saldo de cuenta.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <Badge variant="outline" className="text-lg px-4 py-2 bg-white/80">
              <Bike className="h-5 w-5 mr-2" />
              {bikes.filter(b => b.type === 'mechanical').length} Bicicletas Mecánicas
            </Badge>
            <Badge variant="outline" className="text-lg px-4 py-2 bg-white/80">
              <Zap className="h-5 w-5 mr-2" />
              {bikes.filter(b => b.type === 'electric').length} Bicicletas Eléctricas
            </Badge>
            <Badge variant="outline" className="text-lg px-4 py-2 bg-white/80">
              <CreditCard className="h-5 w-5 mr-2" />
              Mercado Pago Integrado
            </Badge>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              onClick={() => setShowRegistration(true)}
              className="bg-emerald-600 hover:bg-emerald-700 text-lg px-8 py-3"
            >
              Comenzar Ahora
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => setShowLogin(true)}
              className="border-emerald-200 text-emerald-700 hover:bg-emerald-50 text-lg px-8 py-3"
            >
              Ya tengo cuenta
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
          ¿Por qué elegir BicPop?
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="border-emerald-100 hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                <CreditCard className="h-6 w-6 text-emerald-600" />
              </div>
              <CardTitle className="text-emerald-800">Pago Seguro</CardTitle>
              <CardDescription>
                Integración completa con Mercado Pago: tarjetas, PSE, Nequi y más opciones de pago
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-blue-100 hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-blue-600" />
              </div>
              <CardTitle className="text-blue-800">KYC Verificado</CardTitle>
              <CardDescription>
                Sistema de verificación de identidad para garantizar la seguridad de todos los usuarios
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-purple-100 hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Clock className="h-6 w-6 text-purple-600" />
              </div>
              <CardTitle className="text-purple-800">Disponible 24/7</CardTitle>
              <CardDescription>
                Alquila bicicletas en cualquier momento del día con nuestro sistema automatizado
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-green-100 hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <MapPin className="h-6 w-6 text-green-600" />
              </div>
              <CardTitle className="text-green-800">Múltiples Ubicaciones</CardTitle>
              <CardDescription>
                Puntos estratégicos en Centro Histórico, Universidad del Cauca, Terminal y más
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-orange-100 hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                <Star className="h-6 w-6 text-orange-600" />
              </div>
              <CardTitle className="text-orange-800">Calidad Premium</CardTitle>
              <CardDescription>
                Bicicletas mecánicas y eléctricas en excelente estado, mantenimiento regular
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-pink-100 hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-pink-600" />
              </div>
              <CardTitle className="text-pink-800">Comunidad Activa</CardTitle>
              <CardDescription>
                Únete a miles de usuarios que ya disfrutan de una movilidad sostenible en Popayán
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* Bike Preview Section */}
      <section className="container mx-auto px-4 py-16 bg-white/50 rounded-3xl mx-4 mb-16">
        <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Nuestras Bicicletas Disponibles
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {bikes.slice(0, 6).map((bike) => (
            <Card key={bike.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-video bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                <img
                  src={bike.image}
                  alt={bike.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-lg">{bike.name}</h4>
                  <Badge variant={bike.type === 'electric' ? 'default' : 'secondary'}>
                    {bike.type === 'electric' ? (
                      <>
                        <Zap className="h-3 w-3 mr-1" />
                        Eléctrica
                      </>
                    ) : (
                      <>
                        <Bike className="h-3 w-3 mr-1" />
                        Mecánica
                      </>
                    )}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 mb-3">{bike.location}</p>
                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold text-emerald-600">
                    <p>
                      ${bike.pricePerHour?.toLocaleString?.('es-CO') ?? '---'}/hora
                    </p>

                  </span>
                  {bike.type === 'electric' && bike.batteryLevel && (
                    <span className="text-sm text-green-600">
                      Batería: {bike.batteryLevel}%
                    </span>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-8">
          <Button
            size="lg"
            onClick={() => setShowRegistration(true)}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            Ver Todas las Bicicletas
          </Button>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <div className="bg-gradient-to-r from-emerald-500 to-blue-500 rounded-3xl p-12 text-white">
          <h3 className="text-3xl font-bold mb-4">
            ¿Listo para tu próxima aventura?
          </h3>
          <p className="text-xl mb-8 text-emerald-100">
            Regístrate ahora y obtén $75,000 COP de saldo inicial para tus primeros viajes
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              variant="secondary"
              onClick={() => setShowRegistration(true)}
              className="bg-white text-emerald-600 hover:bg-gray-100 text-lg px-8 py-3"
            >
              Crear Cuenta Gratis
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => setShowLogin(true)}
              className="border-white text-white hover:bg-white/10 text-lg px-8 py-3"
            >
              Iniciar Sesión
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white/80 backdrop-blur-sm border-t border-emerald-100 py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <h4 className="text-xl font-bold text-emerald-600">🚴‍♀️ BicPop</h4>
            <Badge variant="outline" className="border-emerald-200 text-emerald-700">
              Powered by Mercado Pago
            </Badge>
          </div>
          <p className="text-gray-600">
            Movilidad sostenible para Popayán • Alquiler de bicicletas con tecnología
          </p>
        </div>
      </footer>
    </div>
  );
}