// Mercado Pago configuration and integration - Versión React
export const MERCADO_PAGO_CONFIG = {
  accessToken: 'APP_USR-1567162011820820-101917-1042db296f815499636fb46308e6c649-2935832210',
  baseUrl: 'https://api.mercadopago.com',
  checkoutUrl: 'https://www.mercadopago.com.co/checkout/v1/redirect'
};

export interface MercadoPagoPreference {
  items: Array<{
    title: string;
    quantity: number;
    unit_price: number;
    currency_id: string;
  }>;
  payer: {
    email: string;
    name?: string;
    surname?: string;
  };
  back_urls: {
    success: string;
    failure: string;
    pending: string;
  };
  auto_return: string;
  notification_url?: string;
  external_reference: string;
}

export interface MercadoPagoResponse {
  id: string;
  init_point: string;
  sandbox_init_point: string;
  date_created: string;
  items: Array<{
    id: string;
    title: string;
    quantity: number;
    unit_price: number;
  }>;
  payer: {
    email: string;
  };
}

export interface MercadoPagoPaymentStatus {
  id: string;
  method: string;
  amount?: number;
  transaction_amount?: number;
  bike: string;
  duration: number;
  timestamp?: string;
  date_created?: string;
  status: string;
};

// Create payment preference - VERSIÓN SIMPLIFICADA PARA REACT
export const createPaymentPreference = async (
  bikeRental: {
    bikeName: string;
    duration: number;
    pricePerHour: number;
    userEmail: string;
    userName?: string;
  }
): Promise<MercadoPagoResponse> => {
  // En React, siempre usar el mock
  console.log("🔧 React - Usando createMockPreference automáticamente");
  
  return createMockPreference(
    `bike-${Date.now()}`,
    bikeRental.bikeName,
    bikeRental.duration,
    bikeRental.duration * bikeRental.pricePerHour,
    bikeRental.userEmail,
    bikeRental.userName || 'Usuario BicPop'
  );
};

// Mock para desarrollo - MEJORADO
export const createMockPreference = async (
  bikeId: string,
  bikeName: string,
  duration: number,
  totalCost: number,
  userEmail: string,
  userName: string
): Promise<MercadoPagoResponse> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));

  const mockId = `DEMO_${Date.now()}`;
  const mockResponse: MercadoPagoResponse = {
    id: mockId,
    init_point: `${MERCADO_PAGO_CONFIG.checkoutUrl}?pref_id=${mockId}&demo=true`,
    sandbox_init_point: `${MERCADO_PAGO_CONFIG.checkoutUrl}?pref_id=${mockId}&demo=true`,
    date_created: new Date().toISOString(),
    items: [
      {
        id: bikeId,
        title: `Alquiler ${bikeName} - ${duration}h`,
        quantity: 1,
        unit_price: totalCost
      }
    ],
    payer: {
      email: userEmail
    }
  };

  console.log("🎭 Mock preference created:", mockResponse);
  return mockResponse;
};

// Simulate payment processing for demo - MEJORADO
export const simulatePaymentSuccess = (preferenceId: string): MercadoPagoPaymentStatus => {
  const paymentId = `PAY_${Date.now()}`;
  
  return {
    id: paymentId,
    method: 'mercado_pago',
    transaction_amount: 0,
    bike: 'Bicicleta Demo',
    duration: 1,
    date_created: new Date().toISOString(),
    status: 'approved'
  };
};

// Get payment status (mock implementation) - MEJORADO
export const getPaymentStatus = async (paymentId: string): Promise<MercadoPagoPaymentStatus> => {
  console.log("🔍 Obteniendo estado de pago demo:", paymentId);
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  return {
    id: paymentId,
    method: 'mercado_pago',
    transaction_amount: 10000, // Ejemplo de monto
    bike: 'Bicicleta Demo',
    duration: 2,
    date_created: new Date().toISOString(),
    status: paymentId.includes('DEMO') ? 'pending' : 'approved'
  };
};

// Función de debug SIMPLIFICADA para React
export const debugMercadoPagoConnection = async (): Promise<boolean> => {
  console.log("🔧 React - Modo demo activado, sin verificación de conexión real");
  return false; // Siempre false para usar mock
};

// ✅ Servicio completo de Mercado Pago - VERSIÓN REACT
export const mercadoPagoService = {
  createPaymentPreference,
  getPaymentStatus,
  simulatePaymentSuccess,
  createMockPreference,
  debugMercadoPagoConnection
};