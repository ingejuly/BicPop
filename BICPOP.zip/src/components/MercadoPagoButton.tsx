import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Loader2, CheckCircle, AlertCircle, X } from 'lucide-react';
import { mercadoPagoService, type MercadoPagoPaymentStatus } from '@/lib/mercadopago';
import CheckoutDemo from './CheckoutDemo';

interface MercadoPagoButtonProps {
  bikeId: string;
  bikeName: string;
  duration: number;
  totalCost: number;
  userEmail: string;
  userName: string;
  onPaymentSuccess: (paymentData: MercadoPagoPaymentStatus) => void;
  onPaymentError: (error: string) => void;
}

export default function MercadoPagoButton({
  bikeId,
  bikeName,
  duration,
  totalCost,
  userEmail,
  userName,
  onPaymentSuccess,
  onPaymentError,
}: MercadoPagoButtonProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [showCheckoutDemo, setShowCheckoutDemo] = useState(false);
  const [currentPreferenceId, setCurrentPreferenceId] = useState<string | null>(null);

  const handleCreatePreference = async () => {
    setIsLoading(true);
    
    try {
      console.log("🔧 Creando sesión demo de pago...");
      
      const preference = await mercadoPagoService.createMockPreference(
        bikeId,
        bikeName,
        duration,
        totalCost,
        userEmail,
        userName
      );

      setCurrentPreferenceId(preference.id);
      setShowCheckoutDemo(true);
      setIsLoading(false); // Quitar loading cuando se muestra el checkout
      
      console.log("🪟 Mostrando checkout demo...");

    } catch (error) {
      console.error('❌ Error en modo demo:', error);
      onPaymentError('Error al crear la sesión de pago demo');
      setIsLoading(false);
    }
  };

  const handlePaymentSuccess = () => {
    if (!currentPreferenceId) return;
    
    try {
      const paymentResult = mercadoPagoService.simulatePaymentSuccess(currentPreferenceId);
      
      const enhancedPaymentData: MercadoPagoPaymentStatus = {
        ...paymentResult,
        bike: bikeName,
        duration: duration,
        transaction_amount: totalCost,
        method: 'mercado_pago',
        status: 'approved'
      };
      
      console.log("✅ Pago demo procesado exitosamente:", enhancedPaymentData);
      onPaymentSuccess(enhancedPaymentData);
      setShowCheckoutDemo(false);
      setCurrentPreferenceId(null);
    } catch (error) {
      console.error('❌ Error procesando pago demo:', error);
      onPaymentError('Error al procesar el resultado del pago demo');
      setShowCheckoutDemo(false);
      setCurrentPreferenceId(null);
    }
  };

  const handlePaymentClose = () => {
    console.log("❌ Pago cancelado por el usuario");
    setShowCheckoutDemo(false);
    setCurrentPreferenceId(null);
  };

  const handleCloseCheckout = () => {
    console.log("🔒 Cerrando checkout manualmente");
    setShowCheckoutDemo(false);
    setCurrentPreferenceId(null);
  };

  return (
    <>
      <div className="space-y-4">
        {/* Indicador de MODO DEMO */}
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
          <div className="flex items-center space-x-2">
            <AlertCircle className="h-4 w-4 text-purple-600" />
            <div className="text-sm text-purple-800">
              <p className="font-medium">MODO DEMO ACTIVADO</p>
              <p className="text-xs">Simulación de pago para desarrollo</p>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-500 p-2 rounded-full">
              <CreditCard className="h-5 w-5 text-white" />
            </div>
            <div>
              <h4 className="font-semibold text-blue-900">Mercado Pago</h4>
              <p className="text-sm text-blue-700">Pago seguro con tarjeta o PSE</p>
            </div>
          </div>
          <Badge className="bg-green-500">Seguro</Badge>
        </div>

        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-medium text-gray-900 mb-2">Resumen del pago</h4>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Bicicleta:</span>
              <span className="font-medium">{bikeName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Duración:</span>
              <span className="font-medium">{duration} hora{duration > 1 ? 's' : ''}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Precio por hora:</span>
              <span className="font-medium">${(totalCost / duration).toLocaleString('es-CO')} COP</span>
            </div>
            <div className="flex justify-between border-t pt-2 mt-2">
              <span className="font-semibold">Total:</span>
              <span className="font-bold text-green-600">
                ${totalCost.toLocaleString('es-CO')} COP
              </span>
            </div>
          </div>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
          <div className="flex items-start space-x-2">
            <CheckCircle className="h-4 w-4 text-yellow-600 mt-0.5" />
            <div className="text-sm text-yellow-800">
              <p className="font-medium mb-1">En modo demo:</p>
              <ul className="text-xs space-y-0.5">
                <li>• Se abrirá un simulador de checkout</li>
                <li>• Elige "Pago Exitoso" para continuar</li>
                <li>• Se cerrará automáticamente en 5 segundos</li>
                <li>• No se requiere conexión externa</li>
              </ul>
            </div>
          </div>
        </div>

        <Button
          onClick={handleCreatePreference}
          disabled={isLoading || showCheckoutDemo}
          className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white font-medium py-3"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creando sesión demo...
            </>
          ) : (
            <>
              <CreditCard className="mr-2 h-4 w-4" />
              {showCheckoutDemo ? 'Checkout Abierto' : 'Probar Pago con Mercado Pago (Demo)'}
            </>
          )}
        </Button>

        <p className="text-xs text-gray-500 text-center">
          💡 Este es un simulador de pago para desarrollo
        </p>
      </div>

      {/* Modal de Checkout Demo - FIXED */}
      {showCheckoutDemo && currentPreferenceId && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="relative max-w-md w-full">
            {/* Botón de cerrar */}
            <button
              onClick={handleCloseCheckout}
              className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 z-10 hover:bg-red-600"
            >
              <X className="h-4 w-4" />
            </button>
            
            <CheckoutDemo
              preferenceId={currentPreferenceId}
              onSuccess={handlePaymentSuccess}
              onClose={handlePaymentClose}
            />
          </div>
        </div>
      )}
    </>
  );
}