import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckCircle, XCircle, Clock, CreditCard, Shield, Lock, User, Calendar } from 'lucide-react';

interface CheckoutDemoProps {
  preferenceId: string;
  onSuccess: () => void;
  onClose: () => void;
}

export default function CheckoutDemo({ preferenceId, onSuccess, onClose }: CheckoutDemoProps) {
  const [timeLeft, setTimeLeft] = useState(60); // Más tiempo para llenar datos
  const [step, setStep] = useState<'form' | 'processing' | 'success' | 'error'>('form');
  const [cardData, setCardData] = useState({
    number: '',
    name: '',
    expiry: '',
    cvv: ''
  });

  useEffect(() => {
    if (timeLeft === 0 && step === 'form') {
      onClose();
      return;
    }

    if (step === 'form') {
      const timer = setTimeout(() => {
        setTimeLeft(timeLeft - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [timeLeft, step, onClose]);

  const handleInputChange = (field: string, value: string) => {
    let formattedValue = value;

    // Formatear número de tarjeta (agregar espacios cada 4 dígitos)
    if (field === 'number') {
      formattedValue = value.replace(/\s/g, '').replace(/(\d{4})/g, '$1 ').trim();
      if (formattedValue.length > 19) formattedValue = formattedValue.slice(0, 19);
    }

    // Formatear fecha de expiración (MM/YY)
    if (field === 'expiry') {
      formattedValue = value.replace(/\D/g, '');
      if (formattedValue.length >= 3) {
        formattedValue = formattedValue.slice(0, 2) + '/' + formattedValue.slice(2, 4);
      }
      if (formattedValue.length > 5) formattedValue = formattedValue.slice(0, 5);
    }

    // Limitar CVV a 3-4 dígitos
    if (field === 'cvv') {
      formattedValue = value.replace(/\D/g, '').slice(0, 4);
    }

    setCardData(prev => ({
      ...prev,
      [field]: formattedValue
    }));
  };

  const handlePayment = async (success: boolean) => {
    setStep('processing');
    
    // Simular procesamiento del pago
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    if (success) {
      setStep('success');
      await new Promise(resolve => setTimeout(resolve, 1500));
      onSuccess();
    } else {
      setStep('error');
    }
  };

  const isFormValid = () => {
    return cardData.number.replace(/\s/g, '').length === 16 &&
           cardData.name.length >= 3 &&
           cardData.expiry.length === 5 &&
           cardData.cvv.length >= 3;
  };

  const getCardType = (number: string) => {
    const cleanNumber = number.replace(/\s/g, '');
    if (/^4/.test(cleanNumber)) return 'Visa';
    if (/^5[1-5]/.test(cleanNumber)) return 'Mastercard';
    if (/^3[47]/.test(cleanNumber)) return 'American Express';
    return 'Tarjeta';
  };

  if (step === 'processing') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-2xl border-0">
          <CardContent className="text-center py-12">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-500 mx-auto mb-4"></div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Procesando Pago</h3>
            <p className="text-gray-600">Verificando tu información de pago...</p>
            <div className="mt-4 flex justify-center space-x-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'success') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-2xl border-0">
          <CardContent className="text-center py-12">
            <div className="bg-green-500 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">¡Pago Exitoso!</h3>
            <p className="text-gray-600 mb-4">Tu transacción ha sido aprobada</p>
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 mt-4">
              <p className="text-sm text-green-800">ID: {preferenceId}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'error') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-2xl border-0">
          <CardContent className="text-center py-12">
            <div className="bg-red-500 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <XCircle className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Pago Rechazado</h3>
            <p className="text-gray-600 mb-4">No pudimos procesar tu pago</p>
            <Button onClick={() => setStep('form')} className="bg-blue-500 hover:bg-blue-600">
              Intentar Nuevamente
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-2xl border-0">
        <CardHeader className="text-center pb-4 border-b">
          <div className="flex justify-center space-x-3 mb-4">
            <div className="bg-blue-500 w-10 h-10 rounded-full flex items-center justify-center">
              <CreditCard className="h-5 w-5 text-white" />
            </div>
            <div className="bg-green-500 w-10 h-10 rounded-full flex items-center justify-center">
              <Shield className="h-5 w-5 text-white" />
            </div>
            <div className="bg-purple-500 w-10 h-10 rounded-full flex items-center justify-center">
              <Lock className="h-5 w-5 text-white" />
            </div>
          </div>
          <CardTitle className="text-xl text-gray-900">Checkout Seguro</CardTitle>
          <p className="text-gray-600 text-sm mt-1">Simulación de Mercado Pago</p>
        </CardHeader>
        
        <CardContent className="space-y-6 pt-6">
          {/* Tarjeta de Crédito Preview */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-4 text-white shadow-lg">
            <div className="flex justify-between items-start mb-6">
              <div className="text-sm opacity-90">Número de Tarjeta</div>
              <div className="text-xs bg-white/20 px-2 py-1 rounded">{getCardType(cardData.number)}</div>
            </div>
            <div className="text-lg font-mono tracking-wider mb-6 min-h-6">
              {cardData.number || '•••• •••• •••• ••••'}
            </div>
            <div className="flex justify-between items-center">
              <div>
                <div className="text-xs opacity-90">Titular</div>
                <div className="text-sm font-medium truncate max-w-32">
                  {cardData.name || 'NOMBRE DEL TITULAR'}
                </div>
              </div>
              <div>
                <div className="text-xs opacity-90">Expira</div>
                <div className="text-sm font-mono">
                  {cardData.expiry || 'MM/AA'}
                </div>
              </div>
            </div>
          </div>

          {/* Formulario de Tarjeta */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="cardNumber" className="flex items-center text-sm">
                <CreditCard className="h-4 w-4 mr-2" />
                Número de Tarjeta
              </Label>
              <Input
                id="cardNumber"
                placeholder="1234 5678 9012 3456"
                value={cardData.number}
                onChange={(e) => handleInputChange('number', e.target.value)}
                className="mt-1"
                maxLength={19}
              />
            </div>

            <div>
              <Label htmlFor="cardName" className="flex items-center text-sm">
                <User className="h-4 w-4 mr-2" />
                Nombre del Titular
              </Label>
              <Input
                id="cardName"
                placeholder="JUAN PEREZ"
                value={cardData.name}
                onChange={(e) => handleInputChange('name', e.target.value.toUpperCase())}
                className="mt-1"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="cardExpiry" className="flex items-center text-sm">
                  <Calendar className="h-4 w-4 mr-2" />
                  Fecha de Expiración
                </Label>
                <Input
                  id="cardExpiry"
                  placeholder="MM/AA"
                  value={cardData.expiry}
                  onChange={(e) => handleInputChange('expiry', e.target.value)}
                  className="mt-1"
                  maxLength={5}
                />
              </div>
              <div>
                <Label htmlFor="cardCvv" className="flex items-center text-sm">
                  <Lock className="h-4 w-4 mr-2" />
                  CVV
                </Label>
                <Input
                  id="cardCvv"
                  placeholder="123"
                  value={cardData.cvv}
                  onChange={(e) => handleInputChange('cvv', e.target.value)}
                  className="mt-1"
                  maxLength={4}
                  type="password"
                />
              </div>
            </div>
          </div>

          {/* Información de Demo */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
            <div className="flex items-start space-x-2">
              <Shield className="h-4 w-4 text-yellow-600 mt-0.5" />
              <div className="text-sm text-yellow-800">
                <p className="font-medium">Datos de Prueba</p>
                <p className="text-xs mt-1">
                  Usa cualquier número de tarjeta. Ejemplo: <code className="bg-yellow-100 px-1">4111 1111 1111 1111</code>
                </p>
              </div>
            </div>
          </div>

          {/* Timer y Botones */}
          <div className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-blue-600" />
                  <span className="text-sm text-blue-800">
                    Tiempo restante: <span className="font-bold">{timeLeft}s</span>
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button 
                onClick={() => handlePayment(false)}
                variant="outline"
                className="h-12 border-red-200 text-red-700 hover:bg-red-50"
              >
                <XCircle className="h-4 w-4 mr-2" />
                Simular Rechazo
              </Button>
              
              <Button 
                onClick={() => handlePayment(true)}
                disabled={!isFormValid()}
                className="h-12 bg-green-500 hover:bg-green-600"
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Pagar ${(10000).toLocaleString('es-CO')}
              </Button>
            </div>
          </div>

          {/* Información de Seguridad */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-3">
            <div className="flex items-center space-x-2">
              <Lock className="h-4 w-4 text-green-600" />
              <div className="text-sm text-green-800">
                <p className="font-medium">Ambiente Seguro de Pruebas</p>
                <p className="text-xs mt-1">
                  No se procesarán pagos reales. Todos los datos son simulados.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}