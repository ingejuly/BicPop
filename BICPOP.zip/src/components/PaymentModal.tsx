import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Bike, Clock, CreditCard, Wallet, CheckCircle, X } from 'lucide-react';
import MercadoPagoButton from './MercadoPagoButton';
import type { Bike as BikeType } from '@/lib/bikes';
import type { MercadoPagoPaymentStatus } from '@/lib/mercadopago';

interface PaymentData {
  id: string;
  method: string;
  amount?: number;
  transaction_amount?: number;
  bike: string;
  duration: number;
  timestamp?: string;
  date_created?: string;
  status: string;
}

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  bike: BikeType | null;
  userEmail: string;
  userBalance: number;
  onPayment: (paymentData: PaymentData | MercadoPagoPaymentStatus) => void;
}

const DURATION_OPTIONS = [
  { hours: 1, label: '1 hora' },
  { hours: 2, label: '2 horas' },
  { hours: 3, label: '3 horas' },
  { hours: 4, label: '4 horas' },
  { hours: 6, label: '6 horas' },
  { hours: 8, label: '8 horas' },
  { hours: 12, label: '12 horas' },
  { hours: 24, label: '24 horas' },
];

export default function PaymentModal({
  isOpen,
  onClose,
  bike,
  userEmail,
  userBalance,
  onPayment,
}: PaymentModalProps) {
  const [selectedDuration, setSelectedDuration] = useState(2);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'balance' | 'mercadopago'>('balance');

  if (!bike) return null;

  const totalCost = bike.pricePerHour * selectedDuration;
  const hasEnoughBalance = userBalance >= totalCost;

  const handleBalancePayment = async () => {
    if (!hasEnoughBalance) return;
    
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      const paymentData: PaymentData = {
        id: `BAL_${Date.now()}`,
        method: 'account_balance',
        amount: totalCost,
        bike: bike.name,
        duration: selectedDuration,
        timestamp: new Date().toISOString(),
        status: 'confirmed'
      };
      
      onPayment(paymentData);
      setIsProcessing(false);
      onClose();
    }, 1500);
  };

  const handleMercadoPagoSuccess = (paymentData: MercadoPagoPaymentStatus) => {
    const bookingData: PaymentData = {
      ...paymentData,
      method: 'mercado_pago',
      bike: bike.name,
      duration: selectedDuration,
      amount: totalCost,
      status: 'confirmed'
    };
    
    onPayment(bookingData);
    onClose();
  };

  const handleMercadoPagoError = (error: string) => {
    alert(`Error en el pago: ${error}`);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Bike className="h-5 w-5 text-emerald-600" />
            <span>Reservar Bicicleta</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Bike Summary */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center space-x-3">
              <img
                src={bike.image}
                alt={bike.name}
                className="w-16 h-16 object-cover rounded-lg"
              />
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900">{bike.name}</h3>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge variant={bike.type === 'electric' ? 'default' : 'secondary'}>
                    {bike.type === 'electric' ? 'Eléctrica' : 'Mecánica'}
                  </Badge>
                  <span className="text-sm text-gray-600">{bike.location}</span>
                </div>
                <p className="text-sm font-medium text-emerald-600 mt-1">
                  ${bike.pricePerHour.toLocaleString('es-CO')} COP/hora
                </p>
              </div>
            </div>
          </div>

          {/* Duration Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              <Clock className="inline h-4 w-4 mr-1" />
              Duración del alquiler
            </label>
            <div className="grid grid-cols-4 gap-2">
              {DURATION_OPTIONS.map((option) => (
                <Button
                  key={option.hours}
                  variant={selectedDuration === option.hours ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedDuration(option.hours)}
                  className="text-xs"
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Cost Summary */}
          <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-200">
            <div className="flex justify-between items-center">
              <span className="text-emerald-800 font-medium">Total a pagar:</span>
              <span className="text-xl font-bold text-emerald-600">
                ${totalCost.toLocaleString('es-CO')} COP
              </span>
            </div>
            <p className="text-sm text-emerald-700 mt-1">
              {selectedDuration} hora{selectedDuration > 1 ? 's' : ''} × ${bike.pricePerHour.toLocaleString('es-CO')} COP
            </p>
          </div>

          {/* Payment Methods */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Método de pago
            </label>
            
            <Tabs value={paymentMethod} onValueChange={(value) => setPaymentMethod(value as 'balance' | 'mercadopago')}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="balance" className="flex items-center space-x-2">
                  <Wallet className="h-4 w-4" />
                  <span>Saldo</span>
                </TabsTrigger>
                <TabsTrigger value="mercadopago" className="flex items-center space-x-2">
                  <CreditCard className="h-4 w-4" />
                  <span>Mercado Pago</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="balance" className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-blue-900">Saldo disponible</h4>
                      <p className="text-sm text-blue-700">Pago instantáneo desde tu cuenta</p>
                    </div>
                    <span className="text-lg font-bold text-blue-600">
                      ${userBalance.toLocaleString('es-CO')} COP
                    </span>
                  </div>
                </div>

                {!hasEnoughBalance && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2">
                      <X className="h-4 w-4 text-red-600" />
                      <span className="text-sm text-red-800">
                        Saldo insuficiente. Necesitas ${(totalCost - userBalance).toLocaleString('es-CO')} COP adicionales.
                      </span>
                    </div>
                  </div>
                )}

                <Button
                  onClick={handleBalancePayment}
                  disabled={!hasEnoughBalance || isProcessing}
                  className="w-full bg-emerald-500 hover:bg-emerald-600"
                >
                  {isProcessing ? (
                    <>Procesando pago...</>
                  ) : (
                    <>
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Pagar con Saldo
                    </>
                  )}
                </Button>
              </TabsContent>

              <TabsContent value="mercadopago" className="space-y-4">
                <MercadoPagoButton
                  bikeId={bike.id}
                  bikeName={bike.name}
                  duration={selectedDuration}
                  totalCost={totalCost}
                  userEmail={userEmail}
                  userName="Usuario BicPop"
                  onPaymentSuccess={(paymentData) => {
                    console.log("✅ Pago de Mercado Pago exitoso:", paymentData);
                    handleMercadoPagoSuccess(paymentData);
                  }}
                  onPaymentError={handleMercadoPagoError}
                />
              </TabsContent>
            </Tabs>
          </div>

          {/* Terms */}
          <div className="text-xs text-gray-500 space-y-1">
            <p>• El tiempo de alquiler comienza al confirmar el pago</p>
            <p>• La bicicleta debe ser devuelta en el mismo punto de recogida</p>
            <p>• Aplican términos y condiciones de uso</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}